//
//  AppDelegate.h
//  testlib
//
//  Created by APPLE on 2/2/15.
//  Copyright (c) 2015年 hsl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

